export const profile = {
  name: "Cherish Sharma",
  username: "Cherish22k",
  avatar: "https://avatars.githubusercontent.com/u/222822131?v=4",
  githubUrl: "https://github.com/Cherish22k",
  tagline: "Developer · Problem Solver · AI Enthusiast",
  intro:
    "I'm a passionate developer who loves building smart, practical tools — from AI-powered scam detectors to voice-controlled assistants. I practice DSA daily, explore new technologies, and turn ideas into working software.",
  location: "India",
  achievements: ["Pull Shark", "Quickdraw"],
};

export const typingRoles = [
  "Full-Stack Developer",
  "AI & ML Enthusiast",
  "Problem Solver",
  "DSA Practitioner",
  "Open Source Contributor",
];

export interface Project {
  id: string;
  name: string;
  description: string;
  longDescription: string;
  tech: string[];
  language: string;
  url: string;
  icon: string;
  featured: boolean;
  accent: string;
}

export const projects: Project[] = [
  {
    id: "scamshield",
    name: "ScamShield",
    description: "Detect fake offers, phishing messages, and online scams using ML.",
    longDescription:
      "A web-based application that combines rule-based logic with Machine Learning to detect fake offers, phishing messages, and online scams — helping users stay safe in the digital world.",
    tech: ["Python", "Machine Learning", "Flask", "NLP"],
    language: "Python",
    url: "https://github.com/Cherish22k/ScamShield",
    icon: "shield",
    featured: true,
    accent: "emerald",
  },
  {
    id: "jarvis",
    name: "JARVIS Virtual Assistant",
    description: "Voice-controlled AI assistant inspired by Iron Man's J.A.R.V.I.S.",
    longDescription:
      "A smart voice-controlled AI assistant built using Python, inspired by Iron Man's J.A.R.V.I.S. It can open applications, send WhatsApp messages, fetch weather and news, and perform various everyday tasks through voice commands.",
    tech: ["Python", "Speech Recognition", "Automation", "APIs"],
    language: "Python",
    url: "https://github.com/Cherish22k/Jarvis--Virtual-Assistant-",
    icon: "bot",
    featured: true,
    accent: "blue",
  },
  {
    id: "tiny-wins",
    name: "Tiny Wins Journal",
    description: "Daily journal to log small wins, track streaks, and visualize consistency.",
    longDescription:
      "A minimal daily journal that helps you log small wins, track streaks, and visualize your consistency over time. Built with a clean, distraction-free interface to encourage daily reflection.",
    tech: ["JavaScript", "HTML/CSS", "LocalStorage"],
    language: "JavaScript",
    url: "https://github.com/Cherish22k/Tiny-Wins-Journal",
    icon: "book",
    featured: true,
    accent: "amber",
  },
  {
    id: "ai-pmo",
    name: "AI PMO Copilot",
    description: "AI-powered PMO assistant for status reports, risk summaries & action trackers.",
    longDescription:
      "An AI-powered PMO assistant that turns raw project artifacts into status reports, risk summaries, and action trackers — with every line traceable back to the source. Nothing is invented, everything is grounded.",
    tech: ["AI", "NLP", "Project Management", "Python"],
    language: "Python",
    url: "https://github.com/Cherish22k/ai-pmo-copilot",
    icon: "briefcase",
    featured: true,
    accent: "violet",
  },
  {
    id: "dsa-practice",
    name: "DSA Practice",
    description: "Daily grind for Data Structures & Algorithms — consistent, structured practice.",
    longDescription:
      "A repository dedicated to daily DSA practice covering arrays, linked lists, stacks, queues, trees, graphs, and dynamic programming. Well-structured solutions aimed at building consistency and problem-solving skills.",
    tech: ["C++", "Data Structures", "Algorithms"],
    language: "C++",
    url: "https://github.com/Cherish22k/DSA-Practice",
    icon: "code",
    featured: false,
    accent: "rose",
  },
  {
    id: "ai-receptionist",
    name: "AI Receptionist",
    description: "AI-powered receptionist for handling queries and interactions.",
    longDescription:
      "An AI-powered receptionist designed to handle visitor queries, manage interactions, and provide intelligent responses — streamlining front-desk operations with automation.",
    tech: ["Python", "AI", "Flask"],
    language: "Python",
    url: "https://github.com/Cherish22k/AI-Receptionist",
    icon: "phone",
    featured: false,
    accent: "cyan",
  },
  {
    id: "java-basics",
    name: "Java Basics",
    description: "Foundational Java programming concepts and exercises.",
    longDescription:
      "A collection of Java programming exercises covering core concepts — from variables and loops to object-oriented programming. A learning repository for building solid Java fundamentals.",
    tech: ["Java", "OOP"],
    language: "Java",
    url: "https://github.com/Cherish22k/Java-Basics",
    icon: "coffee",
    featured: false,
    accent: "orange",
  },
  {
    id: "python-practice",
    name: "Python Learning Practice",
    description: "Python programming practice — from basics to advanced concepts.",
    longDescription:
      "A practice repository for Python programming, covering everything from basic syntax to more advanced topics. A journey of learning Python step by step.",
    tech: ["Python"],
    language: "Python",
    url: "https://github.com/Cherish22k/Python-Learning-Practice",
    icon: "terminal",
    featured: false,
    accent: "sky",
  },
];

export interface SkillCategory {
  title: string;
  skills: { name: string; level: number }[];
}

export const currentSkills: SkillCategory[] = [
  {
    title: "Languages",
    skills: [
      { name: "Python", level: 90 },
      { name: "JavaScript", level: 75 },
      { name: "C++", level: 80 },
      { name: "Java", level: 70 },
      { name: "C", level: 65 },
    ],
  },
  {
    title: "Frameworks & Tools",
    skills: [
      { name: "Flask", level: 80 },
      { name: "Machine Learning", level: 75 },
      { name: "HTML/CSS", level: 85 },
      { name: "Git & GitHub", level: 85 },
    ],
  },
  {
    title: "Concepts",
    skills: [
      { name: "Data Structures & Algorithms", level: 80 },
      { name: "OOP", level: 82 },
      { name: "NLP", level: 70 },
      { name: "Automation", level: 78 },
    ],
  },
];

export const learningGoals = [
  { name: "React & Frontend Development", reason: "To build beautiful, interactive web apps", icon: "layout" },
  { name: "Deep Learning & Neural Networks", reason: "To push deeper into AI and create smarter models", icon: "brain" },
  { name: "Cloud Computing (AWS / GCP)", reason: "To deploy and scale applications globally", icon: "cloud" },
  { name: "Docker & Kubernetes", reason: "To master containerization and orchestration", icon: "box" },
  { name: "System Design", reason: "To architect scalable, robust systems", icon: "server" },
  { name: "TypeScript", reason: "To write safer, more maintainable code", icon: "type" },
];

export const stats = [
  { label: "Repositories", value: 12, icon: "folder" },
  { label: "Languages", value: 5, icon: "code" },
  { label: "Achievements", value: 2, icon: "trophy" },
  { label: "Projects Shipped", value: 6, icon: "rocket" },
];

export const journey = [
  {
    year: "2024 — Present",
    title: "Building AI Projects",
    description: "Created ScamShield, JARVIS Assistant, AI Receptionist, and AI PMO Copilot — applying ML and automation to real-world problems.",
  },
  {
    year: "Ongoing",
    title: "Daily DSA Practice",
    description: "Consistently solving problems in C++ covering arrays, trees, graphs, and dynamic programming to sharpen problem-solving skills.",
  },
  {
    year: "Ongoing",
    title: "Learning Multiple Languages",
    description: "Exploring Python, Java, C++, and JavaScript to build a versatile skill set across paradigms and ecosystems.",
  },
  {
    year: "Next Up",
    title: "Expanding Into Web & Cloud",
    description: "Diving into React, TypeScript, cloud platforms, and containerization to build and deploy full-scale applications.",
  },
];
