import { Github, ArrowUp, Heart } from "lucide-react";
import { profile } from "@/data/portfolio";

export default function Footer() {
  return (
    <footer className="relative border-t border-white/5 py-12 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center font-display font-bold text-sm text-black">
              CS
            </div>
            <div>
              <div className="font-display font-semibold text-sm text-white">{profile.name}</div>
              <div className="text-xs text-gray-500">{profile.tagline}</div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <a
              href={profile.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-emerald-400 transition-colors"
            >
              <Github size={20} />
            </a>
            <a
              href="#home"
              className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-emerald-400 hover:border-emerald-500/30 transition-colors"
            >
              <ArrowUp size={18} />
            </a>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-2">
          <p className="text-xs text-gray-600">
            © {new Date().getFullYear()} {profile.name}. All rights reserved.
          </p>
          <p className="text-xs text-gray-600 flex items-center gap-1.5">
            Built with <Heart size={12} className="text-rose-500 fill-rose-500" /> using React & Tailwind
          </p>
        </div>
      </div>
    </footer>
  );
}
