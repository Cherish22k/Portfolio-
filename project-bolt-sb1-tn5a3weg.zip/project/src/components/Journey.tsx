import Reveal from "@/components/Reveal";
import { journey } from "@/data/portfolio";

export default function Journey() {
  return (
    <section id="journey" className="relative py-28 px-6">
      <div className="max-w-4xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-4">
            <div className="h-px w-12 bg-violet-400" />
            <span className="text-violet-400 font-mono text-sm">04 / Journey</span>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">My Path So Far</h2>
        </Reveal>

        <Reveal delay={150}>
          <p className="text-gray-400 text-lg mb-16 max-w-2xl">
            The milestones that shaped me as a developer — and what's coming next.
          </p>
        </Reveal>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 timeline-line md:-translate-x-1/2" />

          <div className="space-y-12">
            {journey.map((item, i) => (
              <Reveal key={item.title} delay={i * 120}>
                <div className={`relative flex items-start gap-6 md:gap-0 ${i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}>
                  {/* Dot */}
                  <div className="absolute left-4 md:left-1/2 w-4 h-4 rounded-full bg-emerald-400 border-4 border-[#0a0a0f] -translate-x-1/2 mt-6 z-10 pulse-glow" />

                  {/* Card */}
                  <div className={`ml-12 md:ml-0 md:w-[calc(50%-2rem)] ${i % 2 === 0 ? "md:mr-auto md:pr-8" : "md:ml-auto md:pl-8"}`}>
                    <div className="glass-card rounded-2xl p-6">
                      <span className="font-mono text-xs text-emerald-400 mb-2 block">{item.year}</span>
                      <h3 className="font-display text-lg font-semibold text-white mb-2">{item.title}</h3>
                      <p className="text-gray-400 text-sm leading-relaxed">{item.description}</p>
                    </div>
                  </div>

                  {/* Spacer for the other side on desktop */}
                  <div className="hidden md:block md:w-[calc(50%-2rem)]" />
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
