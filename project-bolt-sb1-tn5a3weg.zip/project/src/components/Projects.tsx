import { useState } from "react";
import Reveal from "@/components/Reveal";
import { projects, type Project } from "@/data/portfolio";
import {
  Shield,
  Bot,
  Book,
  Briefcase,
  Code,
  Phone,
  Coffee,
  Terminal,
  Github,
  Star,
  ArrowUpRight,
  X,
} from "lucide-react";

const iconMap: Record<string, typeof Shield> = {
  shield: Shield,
  bot: Bot,
  book: Book,
  briefcase: Briefcase,
  code: Code,
  phone: Phone,
  coffee: Coffee,
  terminal: Terminal,
};

const accentColors: Record<string, { bg: string; text: string; border: string; glow: string }> = {
  emerald: { bg: "bg-emerald-500/10", text: "text-emerald-400", border: "border-emerald-500/30", glow: "group-hover:shadow-emerald-500/20" },
  blue: { bg: "bg-blue-500/10", text: "text-blue-400", border: "border-blue-500/30", glow: "group-hover:shadow-blue-500/20" },
  amber: { bg: "bg-amber-500/10", text: "text-amber-400", border: "border-amber-500/30", glow: "group-hover:shadow-amber-500/20" },
  violet: { bg: "bg-violet-500/10", text: "text-violet-400", border: "border-violet-500/30", glow: "group-hover:shadow-violet-500/20" },
  rose: { bg: "bg-rose-500/10", text: "text-rose-400", border: "border-rose-500/30", glow: "group-hover:shadow-rose-500/20" },
  cyan: { bg: "bg-cyan-500/10", text: "text-cyan-400", border: "border-cyan-500/30", glow: "group-hover:shadow-cyan-500/20" },
  orange: { bg: "bg-orange-500/10", text: "text-orange-400", border: "border-orange-500/30", glow: "group-hover:shadow-orange-500/20" },
  sky: { bg: "bg-sky-500/10", text: "text-sky-400", border: "border-sky-500/30", glow: "group-hover:shadow-sky-500/20" },
};

export default function Projects() {
  const [selected, setSelected] = useState<Project | null>(null);
  const [filter, setFilter] = useState<"all" | "featured">("all");

  const filtered = filter === "featured" ? projects.filter((p) => p.featured) : projects;

  return (
    <section id="projects" className="relative py-28 px-6">
      <div className="max-w-6xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-4">
            <div className="h-px w-12 bg-blue-400" />
            <span className="text-blue-400 font-mono text-sm">02 / Projects</span>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Things I've Built</h2>
        </Reveal>

        <Reveal delay={150}>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl">
            A selection of projects where I turned ideas into working software — from AI assistants to scam detectors.
          </p>
        </Reveal>

        {/* Filter */}
        <Reveal delay={200}>
          <div className="flex gap-3 mb-10">
            <button
              onClick={() => setFilter("all")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filter === "all" ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10"
              }`}
            >
              All Projects ({projects.length})
            </button>
            <button
              onClick={() => setFilter("featured")}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filter === "featured" ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10"
              }`}
            >
              <Star size={14} className="inline mr-1" />
              Featured ({projects.filter((p) => p.featured).length})
            </button>
          </div>
        </Reveal>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((project, i) => {
            const Icon = iconMap[project.icon] ?? Code;
            const accent = accentColors[project.accent] ?? accentColors.emerald;

            return (
              <Reveal key={project.id} delay={i * 80}>
                <div
                  className={`project-card group glass-card rounded-2xl p-6 cursor-pointer h-full flex flex-col ${accent.glow}`}
                  onClick={() => setSelected(project)}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl ${accent.bg} ${accent.border} border flex items-center justify-center`}>
                      <Icon size={22} className={accent.text} />
                    </div>
                    {project.featured && (
                      <Star size={16} className="text-amber-400 fill-amber-400" />
                    )}
                  </div>

                  <h3 className="font-display text-lg font-semibold mb-2 group-hover:text-white transition-colors">
                    {project.name}
                  </h3>
                  <p className="text-gray-400 text-sm leading-relaxed mb-4 flex-grow">
                    {project.description}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tech.slice(0, 3).map((tech) => (
                      <span
                        key={tech}
                        className={`badge ${accent.bg} ${accent.border} ${accent.text}`}
                      >
                        {tech}
                      </span>
                    ))}
                    {project.tech.length > 3 && (
                      <span className="badge bg-white/5 border-white/10 text-gray-400">
                        +{project.tech.length - 3}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-white/5">
                    <span className="text-xs text-gray-500 font-mono">{project.language}</span>
                    <span className={`text-xs font-medium ${accent.text} flex items-center gap-1 group-hover:gap-2 transition-all`}>
                      Details <ArrowUpRight size={14} />
                    </span>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>

      {/* Modal */}
      {selected && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
          onClick={() => setSelected(null)}
        >
          <div
            className="bg-[#16161f] border border-white/10 rounded-2xl max-w-lg w-full p-8 relative max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
              onClick={() => setSelected(null)}
            >
              <X size={20} />
            </button>

            {(() => {
              const Icon = iconMap[selected.icon] ?? Code;
              const accent = accentColors[selected.accent] ?? accentColors.emerald;
              return (
                <>
                  <div className={`w-14 h-14 rounded-xl ${accent.bg} ${accent.border} border flex items-center justify-center mb-5`}>
                    <Icon size={26} className={accent.text} />
                  </div>

                  <h3 className="font-display text-2xl font-bold mb-3">{selected.name}</h3>
                  <p className="text-gray-400 leading-relaxed mb-6">{selected.longDescription}</p>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {selected.tech.map((tech) => (
                      <span key={tech} className={`badge ${accent.bg} ${accent.border} ${accent.text}`}>
                        {tech}
                      </span>
                    ))}
                  </div>

                  <a
                    href={selected.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full py-3 rounded-lg bg-white/5 border border-white/10 text-white font-medium text-sm hover:bg-white/10 transition-colors"
                  >
                    <Github size={18} />
                    View on GitHub
                    <ArrowUpRight size={16} />
                  </a>
                </>
              );
            })()}
          </div>
        </div>
      )}
    </section>
  );
}
