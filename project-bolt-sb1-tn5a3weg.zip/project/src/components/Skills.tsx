import { useEffect, useRef, useState } from "react";
import Reveal from "@/components/Reveal";
import { currentSkills, learningGoals } from "@/data/portfolio";
import {
  Layout,
  Brain,
  Cloud,
  Box,
  Server,
  Type,
  TrendingUp,
} from "lucide-react";

const goalIcons: Record<string, typeof Layout> = {
  layout: Layout,
  brain: Brain,
  cloud: Cloud,
  box: Box,
  server: Server,
  type: Type,
};

function SkillBar({ name, level, delay }: { name: string; level: number; delay: number }) {
  const [width, setWidth] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setTimeout(() => setWidth(level), delay);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [level, delay]);

  return (
    <div ref={ref}>
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm text-gray-300 font-medium">{name}</span>
        <span className="text-xs text-gray-500 font-mono">{level}%</span>
      </div>
      <div className="h-2 rounded-full bg-white/5 overflow-hidden">
        <div
          className="skill-bar-fill bg-gradient-to-r from-emerald-400 to-blue-500"
          style={{ width: `${width}%` }}
        />
      </div>
    </div>
  );
}

export default function Skills() {
  return (
    <section id="skills" className="relative py-28 px-6">
      {/* Marquee strip */}
      <div className="overflow-hidden mb-20 border-y border-white/5 py-4">
        <div className="flex gap-12 marquee whitespace-nowrap">
          {[...Array(2)].map((_, dup) => (
            <div key={dup} className="flex gap-12">
              {["Python", "C++", "JavaScript", "Java", "C", "Flask", "Machine Learning", "NLP", "Git", "HTML/CSS", "OOP", "Automation"].map((tech) => (
                <span key={tech} className="font-display text-2xl font-semibold text-gray-700 hover:text-emerald-400 transition-colors">
                  {tech}
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-5xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-4">
            <div className="h-px w-12 bg-amber-400" />
            <span className="text-amber-400 font-mono text-sm">03 / Skills</span>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">What I Know</h2>
        </Reveal>

        <Reveal delay={150}>
          <p className="text-gray-400 text-lg mb-12 max-w-2xl">
            A blend of languages, frameworks, and concepts I've built up through projects and daily practice.
          </p>
        </Reveal>

        {/* Current skills */}
        <div className="grid md:grid-cols-3 gap-8 mb-24">
          {currentSkills.map((category, catIdx) => (
            <Reveal key={category.title} delay={catIdx * 150}>
              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-display text-lg font-semibold mb-6 text-white">{category.title}</h3>
                <div className="space-y-5">
                  {category.skills.map((skill, i) => (
                    <SkillBar key={skill.name} name={skill.name} level={skill.level} delay={i * 100} />
                  ))}
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        {/* Learning goals */}
        <Reveal>
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp size={20} className="text-emerald-400" />
            <h3 className="font-display text-2xl md:text-3xl font-bold">What I Want to Learn Next</h3>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <p className="text-gray-400 text-lg mb-10 max-w-2xl">
            Always growing — here are the technologies and concepts I'm excited to dive into next.
          </p>
        </Reveal>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {learningGoals.map((goal, i) => {
            const Icon = goalIcons[goal.icon] ?? Layout;
            return (
              <Reveal key={goal.name} delay={i * 80}>
                <div className="glass-card rounded-2xl p-6 group">
                  <div className="flex items-start gap-4">
                    <div className="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                      <Icon size={20} className="text-emerald-400" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white text-sm mb-1">{goal.name}</h4>
                      <p className="text-gray-400 text-sm leading-relaxed">{goal.reason}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
