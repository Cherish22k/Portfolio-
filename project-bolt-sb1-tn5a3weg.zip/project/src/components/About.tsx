import Reveal from "@/components/Reveal";
import { profile } from "@/data/portfolio";
import { Award, Sparkles } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="relative py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-4">
            <div className="h-px w-12 bg-emerald-400" />
            <span className="text-emerald-400 font-mono text-sm">01 / About Me</span>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-8">
            Who I Am
          </h2>
        </Reveal>

        <div className="grid md:grid-cols-5 gap-8 items-start">
          {/* Left: Bio */}
          <Reveal delay={150} className="md:col-span-3">
            <div className="glass-card rounded-2xl p-8">
              <p className="text-gray-300 text-lg leading-relaxed mb-6">
                I'm <span className="text-emerald-400 font-semibold">{profile.name}</span>, a developer driven by curiosity
                and the thrill of building things that work. My journey started with Python and grew into a love for
                AI, automation, and solving real problems with code.
              </p>
              <p className="text-gray-400 leading-relaxed mb-6">
                From building a voice-controlled AI assistant inspired by J.A.R.V.I.S to creating a scam detection
                system with Machine Learning, I enjoy turning ambitious ideas into functional software. I practice
                Data Structures & Algorithms daily to stay sharp and keep improving.
              </p>
              <p className="text-gray-400 leading-relaxed">
                When I'm not coding, I'm exploring new technologies, contributing to open source, and planning my next
                project. I believe in learning by doing — every project is a step forward.
              </p>

              <div className="flex flex-wrap gap-3 mt-8">
                <span className="badge bg-emerald-500/10 border-emerald-500/20 text-emerald-300">
                  <Sparkles size={12} /> Always Learning
                </span>
                <span className="badge bg-blue-500/10 border-blue-500/20 text-blue-300">
                  <Award size={12} /> {profile.achievements.join(" & ")}
                </span>
              </div>
            </div>
          </Reveal>

          {/* Right: Quick facts */}
          <Reveal delay={250} className="md:col-span-2">
            <div className="glass-card rounded-2xl p-8">
              <h3 className="font-display text-lg font-semibold mb-6 text-white">Quick Facts</h3>
              <ul className="space-y-4">
                {[
                  { label: "Name", value: profile.name },
                  { label: "GitHub", value: "@" + profile.username },
                  { label: "Focus", value: "AI, ML & Automation" },
                  { label: "Languages", value: "Python, C++, Java, JS, C" },
                  { label: "Location", value: profile.location },
                  { label: "Status", value: "Open to opportunities" },
                ].map((item) => (
                  <li key={item.label} className="flex justify-between items-start gap-4 text-sm">
                    <span className="text-gray-500 font-medium shrink-0">{item.label}</span>
                    <span className="text-gray-300 text-right">{item.value}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
