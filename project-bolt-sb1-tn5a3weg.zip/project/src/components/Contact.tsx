import { useState } from "react";
import Reveal from "@/components/Reveal";
import { profile } from "@/data/portfolio";
import { Github, Mail, Send, MapPin, CheckCircle2 } from "lucide-react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setForm({ name: "", email: "", message: "" });
    }, 3000);
  };

  return (
    <section id="contact" className="relative py-28 px-6">
      <div className="max-w-4xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-4">
            <div className="h-px w-12 bg-emerald-400" />
            <span className="text-emerald-400 font-mono text-sm">05 / Contact</span>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Let's Connect</h2>
        </Reveal>

        <Reveal delay={150}>
          <p className="text-gray-400 text-lg mb-12 max-w-2xl">
            Have an idea, a project, or just want to say hi? I'm always open to a good conversation.
          </p>
        </Reveal>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Info */}
          <Reveal delay={200}>
            <div className="space-y-4">
              <a
                href={profile.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="glass-card rounded-2xl p-6 flex items-center gap-4 group"
              >
                <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-emerald-500/10 group-hover:border-emerald-500/30 transition-colors">
                  <Github size={22} className="text-gray-300 group-hover:text-emerald-400 transition-colors" />
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-0.5">GitHub</div>
                  <div className="text-sm text-white font-medium">@{profile.username}</div>
                </div>
              </a>

              <div className="glass-card rounded-2xl p-6 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
                  <MapPin size={22} className="text-gray-300" />
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-0.5">Location</div>
                  <div className="text-sm text-white font-medium">{profile.location}</div>
                </div>
              </div>

              <div className="glass-card rounded-2xl p-6 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                  <CheckCircle2 size={22} className="text-emerald-400" />
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-0.5">Status</div>
                  <div className="text-sm text-white font-medium">Open to opportunities</div>
                </div>
              </div>
            </div>
          </Reveal>

          {/* Form */}
          <Reveal delay={300}>
            <form onSubmit={handleSubmit} className="glass-card rounded-2xl p-6 space-y-4">
              <div>
                <label className="text-xs text-gray-500 font-medium block mb-2">Your Name</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 transition-colors"
                  placeholder="Jane Doe"
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 font-medium block mb-2">Your Email</label>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 transition-colors"
                  placeholder="jane@example.com"
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 font-medium block mb-2">Message</label>
                <textarea
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  rows={4}
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 transition-colors resize-none"
                  placeholder="Hey Cherish, I'd love to talk about..."
                />
              </div>
              <button
                type="submit"
                disabled={sent}
                className={`glow-btn w-full flex items-center justify-center gap-2 py-3 rounded-lg font-medium text-sm transition-all ${
                  sent
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                    : "bg-gradient-to-r from-emerald-500 to-blue-500 text-white"
                }`}
              >
                {sent ? (
                  <>
                    <CheckCircle2 size={18} /> Message Sent!
                  </>
                ) : (
                  <>
                    <Send size={16} /> Send Message
                  </>
                )}
              </button>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
