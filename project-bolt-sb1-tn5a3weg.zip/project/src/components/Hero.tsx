import { useEffect, useState } from "react";
import { Github, ArrowDown, Sparkles, MapPin } from "lucide-react";
import { profile, typingRoles, stats } from "@/data/portfolio";
import {
  Folder,
  Code,
  Trophy,
  Rocket,
} from "lucide-react";

const statIcons: Record<string, typeof Folder> = {
  folder: Folder,
  code: Code,
  trophy: Trophy,
  rocket: Rocket,
};

export default function Hero() {
  const [roleIndex, setRoleIndex] = useState(0);
  const [text, setText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const role = typingRoles[roleIndex];
    const speed = isDeleting ? 40 : 90;

    const timeout = setTimeout(() => {
      if (!isDeleting) {
        setText(role.slice(0, text.length + 1));
        if (text.length + 1 === role.length) {
          setTimeout(() => setIsDeleting(true), 1800);
        }
      } else {
        setText(role.slice(0, text.length - 1));
        if (text.length - 1 === 0) {
          setIsDeleting(false);
          setRoleIndex((prev) => (prev + 1) % typingRoles.length);
        }
      }
    }, speed);

    return () => clearTimeout(timeout);
  }, [text, isDeleting, roleIndex]);

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center bg-grid bg-radial-glow overflow-hidden pt-20"
    >
      {/* Floating orbs */}
      <div className="orb animate-orb w-96 h-96 bg-emerald-500 top-20 -left-20" />
      <div className="orb animate-orb w-80 h-80 bg-blue-500 bottom-10 right-0" style={{ animationDelay: "5s" }} />
      <div className="orb animate-orb w-64 h-64 bg-amber-500 top-1/2 left-1/2" style={{ animationDelay: "10s" }} />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 mb-8 fade-in-up">
          <Sparkles size={14} className="text-emerald-400" />
          <span className="text-sm text-emerald-300 font-medium">Welcome to my portfolio</span>
        </div>

        {/* Avatar */}
        <div className="relative inline-block mb-6 fade-in-up" style={{ animationDelay: "0.1s" }}>
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-emerald-400 to-blue-500 blur-2xl opacity-40 spin-slow" />
          <img
            src={profile.avatar}
            alt={profile.name}
            className="relative w-32 h-32 rounded-full border-4 border-white/10 object-cover"
          />
          <div className="absolute bottom-2 right-2 w-5 h-5 rounded-full bg-emerald-400 border-2 border-[#0a0a0f] pulse-glow" />
        </div>

        {/* Name */}
        <h1 className="font-display text-5xl md:text-7xl font-bold mb-3 fade-in-up" style={{ animationDelay: "0.15s" }}>
          <span className="gradient-text">{profile.name}</span>
        </h1>

        {/* Location */}
        <div className="flex items-center justify-center gap-2 text-gray-500 text-sm mb-4 fade-in-up" style={{ animationDelay: "0.2s" }}>
          <MapPin size={14} />
          <span>{profile.location}</span>
        </div>

        {/* Typing role */}
        <div className="h-8 mb-6 fade-in-up" style={{ animationDelay: "0.25s" }}>
          <span className="font-mono text-lg md:text-xl text-emerald-400">
            {text}
            <span className="typing-cursor" />
          </span>
        </div>

        {/* Intro */}
        <p className="max-w-2xl mx-auto text-gray-400 text-base md:text-lg leading-relaxed mb-8 fade-in-up" style={{ animationDelay: "0.3s" }}>
          {profile.intro}
        </p>

        {/* CTAs */}
        <div className="flex items-center justify-center gap-4 mb-16 fade-in-up" style={{ animationDelay: "0.35s" }}>
          <a
            href="#projects"
            className="glow-btn px-6 py-3 rounded-lg bg-gradient-to-r from-emerald-500 to-blue-500 text-white font-medium text-sm"
          >
            View My Work
          </a>
          <a
            href={profile.githubUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-6 py-3 rounded-lg bg-white/5 border border-white/10 text-white font-medium text-sm hover:bg-white/10 transition-colors"
          >
            <Github size={18} />
            GitHub Profile
          </a>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto fade-in-up" style={{ animationDelay: "0.4s" }}>
          {stats.map((stat) => {
            const Icon = statIcons[stat.icon] ?? Folder;
            return (
              <div key={stat.label} className="glass-card rounded-xl p-4 text-center">
                <Icon size={20} className="text-emerald-400 mx-auto mb-2" />
                <div className="font-display text-2xl font-bold text-white">{stat.value}+</div>
                <div className="text-xs text-gray-500 mt-1">{stat.label}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Scroll indicator */}
      <a
        href="#about"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 scroll-indicator text-gray-500 hover:text-emerald-400 transition-colors"
      >
        <ArrowDown size={24} />
      </a>
    </section>
  );
}
